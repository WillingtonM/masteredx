<?php

// $media_id   = $_POST['media_id'];
$media_src  = $_POST['media_src'];
$media_img  = $_POST['media_img'];

$image_dir  = 'mediacontent' . DS . 'gallery' . DS . $media_src . DS . $media_img;
// $media      = get_media_by_id($media_id);
