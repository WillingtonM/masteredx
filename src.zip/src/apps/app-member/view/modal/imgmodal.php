
<div class="modal fade" id="imgModal">
  <div class="modal-dialog modal-xl" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" name="button" class="close" data-dismiss="modal" aria-label="Close" onclick="closeModalByID('popup_modal')"><span aria-hidden="true">&times;</span></button>
      </div>
      <div class="modal-body" style="padding: 0px 15px;">
        <div class="row">
          <img src="<?=$image_dir ?>" alt="Isaah Mhlanga" style="width: 100%;">
        </div>
      </div>
    </div>
  </div>
</div>
