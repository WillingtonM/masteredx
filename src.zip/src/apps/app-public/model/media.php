<?php
$media          = null;
$tabbs_count    = 0; 