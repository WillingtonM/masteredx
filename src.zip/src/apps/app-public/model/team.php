<?php

$users_arr = get_users();