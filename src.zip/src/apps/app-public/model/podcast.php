<?php

redirect_to('media?tab=appearance');
