<?php

// modal variables
$modal_id         = 'users';
$modal_title      = '';
$modal_size       = '';

$modal_backdrop   = true;
$modal_screen     = 'modal-fullscreen-md-down';
$modal_centered   = 'modal-dialog-centered';
$modal_scrollable = 'modal-dialog-scrollable';
