<?php

$cookie_action    = true;
// modal variables
$modal_id         = 'subscription';
$modal_title      = '';
$modal_size       = '';

$modal_backdrop   = true;
$modal_screen     = 'modal-fullscreen-md-down';
$modal_centered   = 'modal-dialog-centered';
$modal_scrollable = 'modal-dialog-scrollable';
