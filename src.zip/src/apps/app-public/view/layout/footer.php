<!-- Copyright -->
<div class="col-12 text-center pb-3">
    <small class="me-1">Copyright © <?= date("Y") ?>, <?= $_ENV['COMPANY_NAME'] ?> </small> <span class="me-1" style="font-size: 1rem;"> &middot;</span>
    <!-- <small class="me-1">
        <a href="terms" class="text-xs text-light">Terms & Conditions</a>
    </small> <span class="me-1" style="font-size: 1rem;"> &middot; </span> -->
    <small class="me-1">
        <a type="button" class="text-xs text-light" onclick="requestModal(post_modal[0], post_modal[0], {});">Login</a>
    </small> <span class="me-1" style="font-size: 1rem;"> &middot; </span>
    <small class=""> <span class="me-1">Powered by</span> <a class="text-xs text-light" target="_blank" href="http://tda.tralon.co.za/">TDA </a> </small>
</div>