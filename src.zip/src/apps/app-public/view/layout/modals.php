
<!-- Login Modal -->
<div class="modal fade" id="modalSupport" tabindex="-1" role="dialog" aria-labelledby="ModalCenterTitle" aria-hidden="true" style="background: rgba(2, 2, 2, 0.5) !important;">
    <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content" style="background: #fff; border-radius: 25px;">
            <div class="modal-header">
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <div class="row/">
                    
                </div>
            </div>
        </div>
    </div>
</div>
