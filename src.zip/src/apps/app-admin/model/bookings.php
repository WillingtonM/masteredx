<?php


$processed_events   = get_events_processed();
// $rsvp               = get_events();

$is_admin   = is_admin_check();
