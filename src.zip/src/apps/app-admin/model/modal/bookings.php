<?php

// $rsvp       = get_events();

$count      = 1;
$attendees  = 0;