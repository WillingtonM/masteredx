<?php

$careers_data   = get_career_applications();
