<?php require_once $config['PARSERS_PATH'] . 'modal' . DS . 'header.php'; ?>

<?php require_once $config['PARSERS_PATH'] . 'careers' . DS . $mmodel_file . '_view.php'; ?>

<?php require_once $config['PARSERS_PATH'] . 'modal' . DS . 'footer.php' ?>