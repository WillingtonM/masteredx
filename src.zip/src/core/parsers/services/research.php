<div class="col shadow bg-white p-3 border-radius-xl mb-2 text-center/">

    <p class="text-sm pt-3">
        Marketing consulting includes thorough analysis and implementation of strategies used in the business marketing message,
        plan, design, and aids to the identification of the appropriate marketing mix elements to effectively send the message
        out. We make thorough evaluation in the current system, create efforts to establish new and developed routes to employ
        towards the improvements and implementation of marketing campaigns.
    </p>

    <p class="text-sm pt-3">
        We also provide various ways to reaching consumers for your product or service. Advertising, Marketing, Research and
        Development are all meant to drive sales and different techniques are employed to achieve this goal. We will ensure your
        team has reliable information and guidance in the quest to build a good reputation of your business through
        product/service development.
    </p>
</div>