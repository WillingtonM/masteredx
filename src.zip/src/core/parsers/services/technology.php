<div class="col shadow bg-white p-3 border-radius-xl mb-2 text-center/">

    <p class="text-sm pt-3">
        Information Technology defines the business’ main streams of income, sustainability, impact and procedure of operation.
        IT is one of the strategic backbones of a successful entity – helps in the marketing, advertising and branding of the
        company.
    </p>

    <p class="text-sm pt-3">
        We specialize in data analytics, solving complex algorithms, building logic gates, coding, developing and implementing
        new systems. Our role is analysing and determining the company’s system requirements as well as making appropriate
        recommendations of software, hardware, systems, etc.
    </p>
</div>