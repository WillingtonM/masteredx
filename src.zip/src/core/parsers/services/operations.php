<div class="col shadow bg-white p-3 border-radius-xl mb-2 text-center/">

    <p class="text-sm pt-3">
        Operational efficiency deals with the improvement in value chains. This involves and includes developing and
        implementing target, service delivery, optimising business processes and so much.
    </p>

    <p class="text-sm pt-3">
        We also study, advice and tutor on the comprehensive function of creating value in form of goods and services. Our role
        is to be concerned with the design, management and improvement of the system that creates the organizations products and
        or services.
    </p>
</div>