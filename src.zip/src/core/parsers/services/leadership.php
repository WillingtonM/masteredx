<div class="col shadow bg-white p-3 border-radius-xl mb-2 text-center/">

    <p class="text-sm pt-3">
        Leadership development is the process which helps expand the capacity of individuals to perform in leadership roles
        within organizations through enhancing the relationships between the team, the executive and management.
    </p>

    <p class="text-sm pt-3">
        Our strength is to build an effective and goal driven team through focusing on four main opportunities, and that is
        Business Management Evaluation, Supervisory Strategies, Team Effectiveness Optimization and Organizational Culture
        Alignment. We are the market leaders in human potential investment and growth and we believe your team is capable.
    </p>
</div>
