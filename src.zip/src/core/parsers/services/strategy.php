<div class="col shadow bg-white p-3 border-radius-xl mb-2 text-center/">

    <p class="text-sm pt-3">
        The alignment of business strategies grants the full authority and permission to the Human Resources a focus and helps
        in prioritizing of goals. The keys include identifying what unifies and motivates team members and the development of a
        strategic plan circling around that understanding.
    </p>

    <p class="text-sm pt-3">
        Our services therefore includes and aims at maximizing human potential on Business Goals Analysis & Development, Revenue
        Increase, Key Decision Making as well as Corporate Strategy & Finance.
    </p>
</div>