<div class="col shadow bg-white p-3 border-radius-xl mb-2 text-center/">

    <p class="text-sm pt-3">
        Our project involvement means we are able to effectively offer and carry out the responsibility for the planning,
        procurement, execution and completion of a project.
    </p>

    <p class="text-sm pt-3">
        It however, has a deeper meaning added to that and that is combining your team’s different ideas and disciplines to
        create a great project.
    </p>
</div>