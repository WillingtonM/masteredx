<button onclick="javascript:location.href='<?= $home_key ?>'" class="btn btn-outline-dark/ btn-dark btn-sm mb-0 border-radius-lg px-4/ py-1/ text-white"> Request a quote </button>
