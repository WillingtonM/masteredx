<span class="mask opacity-6/" style="background-color: rgb(41, 55, 75, .5); ">
    <div class="p-0">
    <div id="top_logo_text_carsl" class="text-center p-3 d-none/ d-lg-block/">
    </div>
    <div class="text-center p-3 pt-3/ font-size-xl">
        <h3 class="font-weight-bolder text-white mb-3"> <span class="text-white"> Personalis<span class="text-warning">ed</span> academic tutoring services </span></h3> 

        <hr class="horizontal light mt-1 mb-2">

        <h6 class="m-0 text-white px-3 font-weight-bolder">
        <p class="font-weight-bolder" style="font-size: 1.1em">
            Customized Learning &nbsp; <span class="me-1" style="font-size: 1rem;"> &middot; </span> &nbsp; Holistic Approach &nbsp; <span class="me-1" style="font-size: 1rem;"> &middot; </span> &nbsp; Affordable Rates
        </p>
        We offer and empower learners with comprehensive and effective educational support services.
        </h6>
    </div>
    </div>
</span>