<input type="hidden" name="booking_type" value="<?= $key ?>">

