<thead class="thead-light">
    <tr class="">
        <th class="text-center d-none d-lg-block" style="width: 1px" scope="col">Case #</th>
        <th scope="col" class="px-2">Name & Initials</th>
        <th scope="col" class="px-2 d-none d-lg-block">Progress Stage</th>
        <th scope="col" class="px-2">Date updated</th>
        <th scope="col" class="px-2 d-none d-lg-block">Stage Date</th>
        <th scope="col" class="px-2"></th>
    </tr>
</thead>